In .NET Compact Framework reference the 
Polenter.SharpSerializer.Compact.dll

In Silverlight reference the
Polenter.SharpSerializer.Silverlight.dll

Otherwise reference
Polenter.SharpSerializer.dll
